package tugas1_123220106;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Polymorphism {

  
    public static void main(String[] args) {
        Programmer x[] = new Programmer[3];
        x[0] = new Programmer();
        x[1] = new Programmer_Ahli();
        x[2] = new Programmer_Profesional();
         for (int i = 0; i < 3; i++) {
             System.out.println("Total gaji yang didapatkan oleh Entitas "+ i +" selama kontrak Adalah " + x[i].gettotalgaji() + " dollar");
             System.out.println("Dengan kontrak selama " + x[i].kontrak + " bulan");
         }
         
         for (int i = 0; i < 3; i++) {
            x[i].perpanjangKontrak();
        }
         
         System.out.println("Setelah Perpanjaangan Kontrak");
         
         for (int i = 0; i < 3; i++) {
             System.out.println("Total gaji yang didapatkan oleh Entitas "+ i +"selama kontrak Adalah "+ x[i].gettotalgaji()+ " dollar");
             System.out.println("Dengan kontrak selama " + x[i].kontrak + " bulan");
         }
         
         
    }
    
}
