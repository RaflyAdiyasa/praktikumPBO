/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220106;

/**
 *
 * @author Acer
 */
public class Programmer {
private double gaji;
double kontrak;
    Programmer(){
    gaji = 4000;
    kontrak = 6;
//        System.out.println("Gaji Perbulan  " + gaji + " dollar ,Dengan kontrak "+ kontrak + "bulan");
    }
    
private double hitungGaji(double gaji, double kontrak) {
return gaji * kontrak;
}

void perpanjangKontrak() {
System.out.println("Memperpanjang kontrak bagi yang paling berkontribusi");
}

void setGaji(double gaji) {
this.gaji = gaji;
}

double gettotalgaji() {
return hitungGaji(gaji, kontrak);
}

}
    
    

