package tugas1_123220106;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Programmer_Ahli extends Programmer{
Programmer_Ahli(){
    kontrak += 6;
    setGaji(6500);
}

void perpanjangKontrak() {
    kontrak += 6;
}
}
