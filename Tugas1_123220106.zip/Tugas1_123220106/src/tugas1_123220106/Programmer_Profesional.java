package tugas1_123220106;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Programmer_Profesional extends Programmer{
    Programmer_Profesional(){
     kontrak += 6;
    setGaji(8200);
    }

void perpanjangKontrak() {
    kontrak += 12;
}
    
}
